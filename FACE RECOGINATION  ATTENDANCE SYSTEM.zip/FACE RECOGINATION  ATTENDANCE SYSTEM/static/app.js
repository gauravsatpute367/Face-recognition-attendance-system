const $ = (selector) => document.querySelector(selector);
const toast = $("#toast");
const video = $("#cameraVideo");
const canvas = $("#cameraCanvas");
const scannerStage = $("#scannerStage");
let cameraStream = null;
let recognizing = false;
let enrollingStream = null;
let scanInterval = null;
let authMode = "login";
let signedInAccount = null;
let attendanceMap = null;
let areaMarker = null;
let areaCircle = null;
let areaCenter = null;
let liveLocationMarker = null;
let liveLocation = null;
let savedArea = null;

function showToast(message, isError = false) {
  toast.textContent = message;
  toast.classList.toggle("error", isError);
  toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 3200);
}

async function requestJson(url, options = {}) {
  const response = await fetch(url, options);
  const body = await response.json();
  if (!response.ok) {
    const error = new Error(body.error || "Something went wrong.");
    error.code = body.code;
    throw error;
  }
  return body;
}

function showAuth(mode = "login", message = "") {
  authMode = mode;
  document.body.classList.remove("signed-in");
  $("#authScreen").hidden = false;
  document.querySelectorAll(".auth-register-only").forEach((element) => {
    element.hidden = mode !== "register";
  });
  document.querySelectorAll(".auth-setup-only").forEach((element) => {
    element.hidden = mode !== "setup";
  });
  $("#authRoleRow").hidden = mode === "setup" || mode === "register";
  $("#authSwitch").hidden = mode === "setup";
  $("#authTitle").textContent = mode === "setup"
    ? "Create your admin account"
    : mode === "register" ? "Join your workspace" : "Welcome back";
  $("#authKicker").textContent = mode === "setup" ? "FIRST-TIME SETUP" : "WORKSPACE ACCESS";
  $("#authCopy").textContent = mode === "setup"
    ? "Set the owner account before inviting students and employees."
    : mode === "register"
      ? "Register as a student or employee. An admin must approve your account."
      : "Sign in to your attendance workspace.";
  $("#authPassword").autocomplete = mode === "setup" || mode === "register" ? "new-password" : "current-password";
  $("#authPassword").minLength = mode === "setup" ? 10 : 8;
  $("#setupName").required = mode === "setup";
  $("#authName").required = mode === "register";
  $("#authSubmit").textContent = mode === "setup"
    ? "Create admin account" : mode === "register" ? "Request access" : "Sign in";
  $("#authSwitch").textContent = mode === "register"
    ? "Already have an account? Sign in"
    : "New here? Register as a student or employee";
  $("#authMessage").textContent = message;
  $("#authMessage").classList.toggle("error", Boolean(message));
  $("#authForm").reset();
  $("#authScreen").hidden = false;
}

function applyRoleVisibility(account) {
  const isAdmin = account.role === "admin";
  $(".admin-tools").classList.toggle("staff-view", !isAdmin);
  $("#adminTools").hidden = false;
  $(".accounts-panel").hidden = !isAdmin;
  document.querySelectorAll(".area-controls, .map-note").forEach((element) => {
    element.hidden = !isAdmin;
  });
  $(".scanner-panel").hidden = isAdmin;
  document.querySelectorAll("[data-open-enroll]").forEach((button) => {
    button.hidden = !isAdmin;
  });
  $(".export-link").hidden = !isAdmin;
  $("#peopleList").classList.toggle("read-only", !isAdmin);
  $(".top-avatar").textContent = initials(account.name);
  $(".profile-avatar").textContent = initials(account.name);
  $(".profile-info strong").textContent = account.name;
  $(".profile-info span").textContent = account.role;
  $("h1 > span:first-child").textContent = account.name.split(/\s+/)[0];
  $(".welcome-subtitle").textContent = isAdmin
    ? "Manage access, location rules, and your team's attendance."
    : "Your attendance dashboard and secure face check-in.";
}

async function enterWorkspace(account) {
  signedInAccount = account;
  $("#authScreen").hidden = true;
  document.body.classList.add("signed-in");
  applyRoleVisibility(account);
  await refreshDashboard();
  initializeMap();
  await loadArea();
  if (account.role === "admin") {
    await loadAccounts();
  } else {
    try {
      const { area } = await requestJson("/api/area");
      $("#scannerHint").textContent = area
        ? `Check in within ${area.label} (${area.radiusMeters} m).`
        : "Attendance area is not configured. Contact your administrator.";
    } catch (error) {
      showToast(error.message, true);
    }
  }
}

async function initializeAuth() {
  try {
    const state = await requestJson("/api/auth/state");
    if (state.account?.approved) {
      await enterWorkspace(state.account);
    } else if (state.setupRequired) {
      showAuth("setup");
    } else {
      showAuth("login");
    }
  } catch (error) {
    showAuth("login", error.message);
  }
}

function initials(name) {
  return name.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
}

function localTime(value) {
  return new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function renderDashboard(data) {
  $("#todayDate").textContent = new Date(`${data.date}T12:00:00`).toLocaleDateString([], {
    weekday: "long", month: "long", day: "numeric", year: "numeric",
  });
  $("#presentCount").textContent = data.present;
  $("#totalCount").textContent = data.total;
  $("#rateCount").textContent = data.rate;
  $("#rateRing").textContent = `${data.rate}%`;
  $(".rate-ring").style.setProperty("--progress", `${data.rate * 3.6}deg`);
  $("#peopleCount").textContent = data.total;
  $("#presentCaption").textContent = data.total
    ? `${data.total - data.present} ${data.total - data.present === 1 ? "person" : "people"} not checked in`
    : "Enroll people to start tracking";
  $("#rosterCount").textContent = data.people.length;
  const weekTotal = data.weekly.reduce((sum, day) => sum + day.count, 0);
  $("#weekTotal").textContent = weekTotal;
  const maxCount = Math.max(...data.weekly.map((day) => day.count), 1);
  const chart = $("#attendanceChart");
  chart.innerHTML = "";
  data.weekly.forEach((day) => {
    const column = document.createElement("div");
    column.className = `chart-column${day.date === data.date ? " today" : ""}`;
    column.setAttribute("aria-label", `${day.day}: ${day.count} check-ins`);
    const tip = document.createElement("span");
    tip.className = "chart-tip";
    tip.textContent = day.count;
    const bar = document.createElement("div");
    bar.className = "chart-bar";
    bar.style.height = `${Math.max((day.count / maxCount) * 80, 3)}%`;
    column.append(tip, bar);
    chart.append(column);
  });
  const recent = $("#recentList");
  recent.innerHTML = data.recent.length ? data.recent.map((person) => `
    <div class="recent-row">
      <div class="person-cell"><span class="person-avatar">${initials(person.name)}</span><span class="person-name">${escapeHtml(person.name)}</span></div>
      <span class="person-meta">${person.attendedOn === data.date ? "Today" : escapeHtml(person.attendedOn)}</span>
      <span class="checkin-tag">${localTime(person.checkedInAt)}</span>
    </div>`).join("") : '<div class="empty-state">No check-ins yet today. Start a face scan to record the first one.</div>';
  const people = $("#peopleList");
  people.innerHTML = data.people.length ? data.people.map((person) => `
    <div class="people-row">
      <div class="person-cell"><span class="person-avatar">${initials(person.name)}</span><span class="person-name">${escapeHtml(person.name)}</span></div>
      <span class="streak">✦ ${person.streak}d</span>
      <button class="delete-person" data-delete-person="${person.id}" title="Remove ${escapeHtml(person.name)}" aria-label="Remove ${escapeHtml(person.name)}">×</button>
    </div>`).join("") : '<div class="empty-state">Your roster is waiting. Enroll the first person.</div>';
}

function escapeHtml(value) {
  const node = document.createElement("span");
  node.textContent = value;
  return node.innerHTML;
}

async function refreshDashboard() {
  try {
    renderDashboard(await requestJson("/api/dashboard"));
  } catch (error) {
    showToast(error.message, true);
  }

  function getCurrentLocation() {
    if (!navigator.geolocation) {
      return Promise.reject(new Error("This browser does not support location access."));
    }
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (position) => resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
        }),
        (error) => reject(new Error(
          error.code === error.PERMISSION_DENIED
            ? "Allow location access to check in."
            : "Could not read your location. Try again outdoors or enable GPS."
        )),
        { enableHighAccuracy: true, timeout: 12000, maximumAge: 10000 },
      );
    });
  }
}

function captureImage(videoElement, canvasElement) {
  canvasElement.width = videoElement.videoWidth;
  canvasElement.height = videoElement.videoHeight;
  const context = canvasElement.getContext("2d");
  context.drawImage(videoElement, 0, 0);
  return canvasElement.toDataURL("image/jpeg", 0.8);
}

async function startCamera() {
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error("Camera access requires HTTPS or localhost and a supported browser.");
  }
  return navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" }, audio: false });
}

function stopCamera() {
  if (scanInterval) window.clearInterval(scanInterval);
  scanInterval = null;
  if (cameraStream) cameraStream.getTracks().forEach((track) => track.stop());
  cameraStream = null;
  video.srcObject = null;
  scannerStage.classList.remove("camera-on", "scanning");
  $("#scanButton").innerHTML = "<span>◉</span> Start camera";
  $("#scannerLabel").textContent = "READY TO SCAN";
  $("#scannerHint").textContent = "Start the camera and look straight ahead.";
}

async function scanFrame() {
  if (!cameraStream || recognizing || video.readyState < 2) return;
  recognizing = true;
  scannerStage.classList.add("scanning");
  $("#scannerLabel").textContent = "ANALYZING FACE";
  try {
    const location = await getCurrentLocation();
    updateLiveLocation(location);
    const result = await requestJson("/api/recognize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        imageData: captureImage(video, canvas),
        latitude: location.latitude,
        longitude: location.longitude,
      }),
    });
    if (result.matched) {
      $("#scannerHint").textContent = result.message;
      $("#scannerLabel").textContent = result.alreadyMarked ? "ALREADY CHECKED IN" : "CHECK-IN SUCCESS";
      if (!result.alreadyMarked) {
        showToast(`${result.name} checked in · ${result.confidence}% match`);
        await refreshDashboard();
      }
      stopCamera();
    } else {
      $("#scannerHint").textContent = result.message;
    }
  } catch (error) {
    $("#scannerHint").textContent = error.message;
    if (error.message.includes("OpenCV")) stopCamera();
  } finally {
    recognizing = false;
    if (cameraStream) {
      scannerStage.classList.remove("scanning");
      $("#scannerLabel").textContent = "LOOKING FOR A FACE";
    }
  }
}

$("#scanButton").addEventListener("click", async () => {
  if (cameraStream) {
    stopCamera();
    return;
  }
  try {
    cameraStream = await startCamera();
    video.srcObject = cameraStream;
    scannerStage.classList.add("camera-on");
    $("#scanButton").innerHTML = "<span>×</span> Stop camera";
    $("#scannerHint").textContent = "Center your face in the frame.";
    $("#scannerLabel").textContent = "LOOKING FOR A FACE";
    scanInterval = window.setInterval(scanFrame, 1400);
  } catch (error) {
    cameraStream = null;
    showToast(error.message, true);
  }
});

const enrollDialog = $("#enrollDialog");
const enrollPreview = $("#enrollPreview");
const enrollSubmit = $("#enrollSubmit");
const enrollCameraButton = $("#enrollCameraButton");
function stopEnrollCamera() {
  if (enrollingStream) enrollingStream.getTracks().forEach((track) => track.stop());
  enrollingStream = null;
  enrollPreview.innerHTML = '<span>◉</span><span>Camera preview appears here</span>';
  enrollCameraButton.textContent = "Open camera";
  enrollSubmit.disabled = true;
}

document.querySelectorAll("[data-open-enroll]").forEach((button) => {
  button.addEventListener("click", () => {
    if (cameraStream) stopCamera();
    $("#enrollMessage").textContent = "";
    $("#personName").value = "";
    enrollDialog.showModal();
  });
});
enrollDialog.addEventListener("close", stopEnrollCamera);
enrollCameraButton.addEventListener("click", async () => {
  try {
    enrollingStream = await startCamera();
    const previewVideo = document.createElement("video");
    previewVideo.autoplay = true;
    previewVideo.playsInline = true;
    previewVideo.muted = true;
    previewVideo.srcObject = enrollingStream;
    enrollPreview.replaceChildren(previewVideo);
    enrollCameraButton.textContent = "Camera ready";
    enrollSubmit.disabled = false;
  } catch (error) {
    $("#enrollMessage").textContent = error.message;
    $("#enrollMessage").classList.add("error");
  }
});
enrollSubmit.addEventListener("click", async () => {
  const name = $("#personName").value.trim();
  const previewVideo = enrollPreview.querySelector("video");
  if (!name || !previewVideo?.videoWidth) {
    $("#enrollMessage").textContent = "Enter a name and wait for the camera preview.";
    $("#enrollMessage").classList.add("error");
    return;
  }
  enrollSubmit.disabled = true;
  $("#enrollMessage").classList.remove("error");
  $("#enrollMessage").textContent = "Checking the image and enrolling…";
  try {
    await requestJson("/api/enroll", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, imageData: captureImage(previewVideo, canvas) }),
    });
    enrollDialog.close();
    showToast(`${name} enrolled successfully.`);
    await refreshDashboard();
  } catch (error) {
    $("#enrollMessage").textContent = error.message;
    $("#enrollMessage").classList.add("error");
    enrollSubmit.disabled = false;
  }
});

$("#peopleList").addEventListener("click", async (event) => {
  const button = event.target.closest("[data-delete-person]");
  if (!button) return;
  const name = button.getAttribute("aria-label").replace(/^Remove /, "");
  if (!window.confirm(`Remove ${name} and all of their attendance records?`)) return;
  try {
    await requestJson(`/api/people/${button.dataset.deletePerson}`, { method: "DELETE" });
    showToast(`${name} and their records were removed.`);
    await refreshDashboard();
  } catch (error) {
    showToast(error.message, true);
  }
});

function updateMapArea(latitude, longitude, radiusMeters = Number($("#areaRadius").value) || 200) {
  areaCenter = { latitude, longitude };
  if (!attendanceMap) return;
  const point = [latitude, longitude];
  if (!areaMarker) {
    areaMarker = window.L.marker(point, { draggable: true }).addTo(attendanceMap);
    areaMarker.on("dragend", () => {
      const position = areaMarker.getLatLng();
      updateMapArea(position.lat, position.lng);
    });
  } else {
    areaMarker.setLatLng(point);
  }
  if (!areaCircle) {
    areaCircle = window.L.circle(point, {
      radius: radiusMeters,
      color: "#73f0cf",
      fillColor: "#73f0cf",
      fillOpacity: 0.12,
      weight: 2,
    }).addTo(attendanceMap);
  } else {
    areaCircle.setLatLng(point);
    areaCircle.setRadius(radiusMeters);
  }
}

function distanceMeters(first, second) {
  const radians = (degrees) => degrees * Math.PI / 180;
  const deltaLatitude = radians(second.latitude - first.latitude);
  const deltaLongitude = radians(second.longitude - first.longitude);
  const value = Math.sin(deltaLatitude / 2) ** 2
    + Math.cos(radians(first.latitude)) * Math.cos(radians(second.latitude))
    * Math.sin(deltaLongitude / 2) ** 2;
  return 6_371_000 * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value));
}

function showLocationStatus(location) {
  const status = $("#locationStatus");
  const detail = $("#locationDetail");
  if (!savedArea) {
    status.className = "location-status waiting";
    status.textContent = "AREA NOT SET";
    detail.textContent = "Ask the administrator to configure the attendance area.";
    return;
  }
  const distance = distanceMeters(savedArea, location);
  const inside = distance <= savedArea.radiusMeters;
  status.className = `location-status ${inside ? "inside" : "outside"}`;
  status.innerHTML = `<i></i> ${inside ? "INSIDE AREA" : "OUTSIDE AREA"}`;
  detail.textContent = `${Math.round(distance)} m from ${savedArea.label} · allowed radius ${savedArea.radiusMeters} m`;
}

function updateLiveLocation(location, centerMap = true) {
  liveLocation = location;
  const point = [location.latitude, location.longitude];
  if (!attendanceMap) return;
  if (!liveLocationMarker) {
    liveLocationMarker = window.L.circleMarker(point, {
      radius: 8,
      color: "#ffffff",
      weight: 2,
      fillColor: "#63aaff",
      fillOpacity: 1,
    }).addTo(attendanceMap).bindTooltip("Your live location");
  } else {
    liveLocationMarker.setLatLng(point);
  }
  if (centerMap) attendanceMap.setView(point, Math.max(attendanceMap.getZoom(), 16));
  showLocationStatus(location);
}

function initializeMap() {
  if (!window.L || attendanceMap) {
    if (!window.L) $("#areaMessage").textContent = "The map library did not load. Check your internet connection.";
    return;
  }
  attendanceMap = window.L.map("attendanceMap").setView([20.5937, 78.9629], 5);
  window.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "&copy; OpenStreetMap contributors",
  }).addTo(attendanceMap);
  attendanceMap.on("click", (event) => {
    updateMapArea(event.latlng.lat, event.latlng.lng);
  });
  window.setTimeout(() => attendanceMap.invalidateSize(), 100);
}

$("#mapSearchForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const query = $("#mapSearchInput").value.trim();
  const results = $("#mapSearchResults");
  if (query.length < 3) {
    results.hidden = false;
    results.textContent = "Enter at least 3 characters to search.";
    return;
  }
  results.hidden = false;
  results.textContent = "Searching map…";
  const searchButton = event.currentTarget.querySelector("button");
  searchButton.disabled = true;
  try {
    const url = new URL("https://nominatim.openstreetmap.org/search");
    url.search = new URLSearchParams({
      q: query,
      format: "jsonv2",
      limit: "5",
    });
    const response = await fetch(url);
    if (!response.ok) throw new Error("Map search is temporarily unavailable. Try again.");
    const places = await response.json();
    results.replaceChildren();
    if (!places.length) {
      results.textContent = "No matching places found. Try a nearby street or city.";
      return;
    }
    places.forEach((place) => {
      const option = document.createElement("button");
      option.type = "button";
      option.className = "map-search-result";
      option.setAttribute("role", "option");
      option.textContent = place.display_name;
      option.addEventListener("click", () => {
        const latitude = Number(place.lat);
        const longitude = Number(place.lon);
        updateMapArea(latitude, longitude);
        attendanceMap?.flyTo([latitude, longitude], 17);
        if (!$("#areaLabel").value.trim() || $("#areaLabel").value === "Main campus") {
          $("#areaLabel").value = place.name || place.display_name.split(",")[0];
        }
        results.hidden = true;
        results.replaceChildren();
        $("#areaMessage").classList.remove("error");
        $("#areaMessage").textContent = "Place selected. Adjust the radius, then save the attendance area.";
      });
      results.append(option);
    });
  } catch (error) {
    results.textContent = error.message;
  } finally {
    searchButton.disabled = false;
  }
});

$("#mapSearchInput").addEventListener("input", () => {
  $("#mapSearchResults").hidden = true;
});

async function loadArea() {
  try {
    const result = await requestJson("/api/area");
    if (!result.area) {
      savedArea = null;
      $("#areaStatus").textContent = "Not configured";
      showLocationStatus(null);
      return;
    }
    savedArea = result.area;
    $("#areaLabel").value = result.area.label;
    $("#areaRadius").value = result.area.radiusMeters;
    updateMapArea(result.area.latitude, result.area.longitude, result.area.radiusMeters);
    attendanceMap?.setView([result.area.latitude, result.area.longitude], 16);
    $("#areaStatus").textContent = `${result.area.radiusMeters} m radius`;
  } catch (error) {
    $("#areaMessage").textContent = error.message;
  }
}

$("#areaRadius").addEventListener("input", () => {
  if (areaCenter) updateMapArea(areaCenter.latitude, areaCenter.longitude);
});
$("#useMyLocation").addEventListener("click", async () => {
  $("#areaMessage").textContent = "Reading this device's location…";
  try {
    const location = await getCurrentLocation();
    updateLiveLocation(location);
    updateMapArea(location.latitude, location.longitude);
    areaCenter = { latitude: location.latitude, longitude: location.longitude };
    $("#areaMessage").textContent = `Location found (±${Math.round(location.accuracy)} m).`;
  } catch (error) {
    $("#areaMessage").textContent = error.message;
  }
});
$("#showLiveLocation").addEventListener("click", async () => {
  $("#locationDetail").textContent = "Finding your current location…";
  try {
    const location = await getCurrentLocation();
    updateLiveLocation(location);
    $("#locationDetail").textContent += ` · GPS accuracy ±${Math.round(location.accuracy)} m`;
  } catch (error) {
    $("#locationStatus").className = "location-status outside";
    $("#locationStatus").innerHTML = "<i></i> LOCATION UNAVAILABLE";
    $("#locationDetail").textContent = error.message;
  }
});
$("#saveArea").addEventListener("click", async () => {
  if (!areaCenter) {
    $("#areaMessage").textContent = "Click the map or use your current location first.";
    $("#areaMessage").classList.add("error");
    return;
  }
  const radiusMeters = Number($("#areaRadius").value);
  $("#areaMessage").classList.remove("error");
  try {
    const result = await requestJson("/api/area", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...areaCenter,
        radiusMeters,
        label: $("#areaLabel").value.trim(),
      }),
    });
    savedArea = result.area;
    $("#areaStatus").textContent = `${result.area.radiusMeters} m radius`;
    if (liveLocation) showLocationStatus(liveLocation);
    $("#areaMessage").textContent = result.message;
    showToast(result.message);
  } catch (error) {
    $("#areaMessage").textContent = error.message;
    $("#areaMessage").classList.add("error");
  }
});

async function loadAccounts() {
  try {
    const result = await requestJson("/api/admin/accounts");
    const pending = result.accounts.filter((account) => !account.approved);
    $("#pendingCount").textContent = `${pending.length} pending`;
    $("#accountList").innerHTML = result.accounts.length ? result.accounts.map((account) => `
      <div class="account-row">
        <div class="person-cell">
          <span class="person-avatar">${initials(account.name)}</span>
          <span><span class="person-name">${escapeHtml(account.name)}</span><span class="person-meta">${escapeHtml(account.username)} · ${escapeHtml(account.role)}</span></span>
        </div>
        ${account.approved
          ? `<span class="account-state approved">APPROVED</span><button class="delete-person" data-remove-account="${account.id}" aria-label="Remove ${escapeHtml(account.username)}">×</button>`
          : `<div class="approval-controls">
              <select data-person-link="${account.id}" aria-label="Choose face profile">
                <option value="">Link face profile…</option>
                ${result.availablePeople.map((person) => `<option value="${person.id}">${escapeHtml(person.name)}</option>`).join("")}
              </select>
              <div class="approval-buttons">
                <button class="scan-button approve-account" data-approve-account="${account.id}">Approve</button>
                <button class="text-action" data-remove-account="${account.id}">Decline</button>
              </div>
            </div>`
        }
      </div>`).join("") : '<div class="empty-state">No student or employee accounts yet.</div>';
  } catch (error) {
    $("#accountList").innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`;
  }
}

$("#accountList").addEventListener("click", async (event) => {
  const approve = event.target.closest("[data-approve-account]");
  const remove = event.target.closest("[data-remove-account]");
  if (approve) {
    const accountId = approve.dataset.approveAccount;
    const personId = Number($(`[data-person-link="${accountId}"]`).value);
    if (!personId) {
      showToast("Enroll and select this person's face profile first.", true);
      return;
    }
    try {
      const result = await requestJson(`/api/admin/accounts/${accountId}/approve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ personId }),
      });
      showToast(result.message);
      await loadAccounts();
    } catch (error) {
      showToast(error.message, true);
    }
  } else if (remove) {
    if (!window.confirm("Remove this account? Attendance records will remain.")) return;
    try {
      await requestJson(`/api/admin/accounts/${remove.dataset.removeAccount}`, { method: "DELETE" });
      await loadAccounts();
      showToast("Account removed.");
    } catch (error) {
      showToast(error.message, true);
    }
  }
});

$("#createAccountForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const values = Object.fromEntries(new FormData(event.currentTarget).entries());
  try {
    const result = await requestJson("/api/admin/accounts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    event.currentTarget.reset();
    showToast(result.message);
    await loadAccounts();
  } catch (error) {
    showToast(error.message, true);
  }
});

$("#refreshButton").addEventListener("click", refreshDashboard);
document.querySelectorAll(".nav-item").forEach((item) => item.addEventListener("click", () => {
  document.querySelectorAll(".nav-item").forEach((link) => link.classList.remove("active"));
  item.classList.add("active");
}));
$("#authSwitch").addEventListener("click", () => {
  showAuth(authMode === "register" ? "login" : "register");
});
$("#authForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const common = {
    username: form.get("username"),
    password: form.get("password"),
  };
  let endpoint;
  let payload;
  if (authMode === "setup") {
    endpoint = "/api/setup-admin";
    payload = { ...common, name: $("#setupName").value };
  } else if (authMode === "register") {
    endpoint = "/api/register";
    payload = {
      ...common,
      name: $("#authName").value,
      role: form.get("registerRole"),
    };
  } else {
    endpoint = "/api/login";
    payload = { ...common, role: form.get("role") };
  }
  $("#authSubmit").disabled = true;
  $("#authMessage").textContent = authMode === "register" ? "Submitting access request…" : "Signing in…";
  $("#authMessage").classList.remove("error");
  try {
    const result = await requestJson(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (authMode === "register") {
      showAuth("login", result.message);
    } else {
      await enterWorkspace(result.account || {
        name: $("#setupName").value, username: form.get("username"), role: "admin",
      });
    }
  } catch (error) {
    if (error.code === "admin_setup_required") {
      showAuth("setup", "Create the administrator account first. Then students and employees can register.");
      return;
    }
    $("#authMessage").textContent = error.message;
    $("#authMessage").classList.add("error");
  } finally {
    $("#authSubmit").disabled = false;
  }
});
$("#logoutButton").addEventListener("click", async () => {
  stopCamera();
  await requestJson("/api/logout", { method: "POST" });
  signedInAccount = null;
  showAuth("login");
});
initializeAuth();
