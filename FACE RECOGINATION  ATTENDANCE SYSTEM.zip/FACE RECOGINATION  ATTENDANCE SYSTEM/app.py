import base64
import binascii
import csv
import io
import json
import os
import re
import secrets
import sqlite3
from math import asin, cos, radians, sin, sqrt
from datetime import date, datetime, timedelta
from functools import wraps
from pathlib import Path

from flask import Flask, Response, jsonify, render_template, request, session
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DATABASE = Path(os.environ.get("ATTENDANCE_DB", BASE_DIR / "attendance.db"))
MAX_IMAGE_BYTES = 4 * 1024 * 1024
FACE_MATCH_THRESHOLD = float(os.environ.get("FACE_MATCH_THRESHOLD", "75"))
FACE_SIZE = (128, 128)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = (MAX_IMAGE_BYTES * 4 // 3) + 16 * 1024
app.config["SECRET_KEY"] = os.environ.get(
    "FLASK_SECRET_KEY", secrets.token_hex(32)
)
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"


class FaceRecognitionUnavailable(RuntimeError):
    pass


class InvalidFaceImage(ValueError):
    pass


class ClosingConnection(sqlite3.Connection):
    def __exit__(self, exception_type, exception, traceback):
        try:
            return super().__exit__(exception_type, exception, traceback)
        finally:
            self.close()


def get_db():
    connection = sqlite3.connect(DATABASE, factory=ClosingConnection)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def init_db():
    DATABASE.parent.mkdir(parents=True, exist_ok=True)
    with get_db() as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS people (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                embedding TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                person_id INTEGER NOT NULL REFERENCES people(id) ON DELETE CASCADE,
                attended_on TEXT NOT NULL,
                checked_in_at TEXT NOT NULL,
                UNIQUE(person_id, attended_on)
            );
            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                name TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL CHECK (role IN ('admin', 'student', 'employee')),
                approved INTEGER NOT NULL DEFAULT 0,
                person_id INTEGER REFERENCES people(id) ON DELETE SET NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            """
        )
        connection.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS accounts_person_unique "
            "ON accounts(person_id) WHERE person_id IS NOT NULL"
        )


def recognition_libraries():
    try:
        import cv2
        import numpy as np
    except ImportError as error:
        raise FaceRecognitionUnavailable(
            "OpenCV is not installed. Run: python -m pip install -r requirements.txt"
        ) from error
    if not hasattr(cv2, "face") or not hasattr(cv2.face, "LBPHFaceRecognizer_create"):
        raise FaceRecognitionUnavailable(
            "OpenCV face recognition is not installed. Run: "
            "python -m pip install -r requirements.txt"
        )
    return cv2, np


def image_from_request():
    if request.is_json:
        payload = request.get_json(silent=True) or {}
        image_data = payload.get("imageData", "")
        if not isinstance(image_data, str):
            raise InvalidFaceImage("A camera image is required.")
        match = re.fullmatch(
            r"data:image/(?:jpeg|jpg|png);base64,([A-Za-z0-9+/=]+)", image_data
        )
        if not match:
            raise InvalidFaceImage(
                "Send imageData as a JPEG or PNG data URL, or upload an image file."
            )
        try:
            image_bytes = base64.b64decode(match.group(1), validate=True)
        except (binascii.Error, ValueError) as error:
            raise InvalidFaceImage("The camera image could not be decoded.") from error
    else:
        image_file = request.files.get("image")
        if image_file is None:
            raise InvalidFaceImage("Upload a JPEG or PNG file using the 'image' field.")
        image_bytes = image_file.read(MAX_IMAGE_BYTES + 1)
    if not image_bytes or len(image_bytes) > MAX_IMAGE_BYTES:
        raise InvalidFaceImage("The image must be smaller than 4 MB.")
    cv2, np = recognition_libraries()
    image = cv2.imdecode(np.frombuffer(image_bytes, dtype="uint8"), cv2.IMREAD_COLOR)
    if image is None:
        raise InvalidFaceImage("The camera image is not valid.")
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    cascade = cv2.CascadeClassifier(
        str(Path(cv2.data.haarcascades) / "haarcascade_frontalface_default.xml")
    )
    if cascade.empty():
        raise FaceRecognitionUnavailable("OpenCV's face detection model could not be loaded.")
    locations = cascade.detectMultiScale(
        gray_image, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80)
    )
    if len(locations) != 1:
        raise InvalidFaceImage(
            "No face found. Move into the camera frame."
            if len(locations) == 0
            else "Please make sure only one face is in the frame."
        )
    x, y, width, height = locations[0]
    face = gray_image[y : y + height, x : x + width]
    return cv2.resize(cv2.equalizeHist(face), FACE_SIZE)


def api_endpoint(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except FaceRecognitionUnavailable as error:
            return jsonify({"error": str(error)}), 503
        except InvalidFaceImage as error:
            return jsonify({"error": str(error)}), 400
        except sqlite3.Error:
            app.logger.exception("Attendance database operation failed")
            return jsonify({"error": "The attendance database could not be accessed."}), 500
        except Exception:
            app.logger.exception("Unexpected attendance API failure")
            return jsonify({"error": "The request could not be completed."}), 500

    return wrapped


def current_account():
    account_id = session.get("account_id")
    if not account_id:
        return None
    with get_db() as connection:
        return connection.execute(
            "SELECT id, username, name, role, approved, person_id FROM accounts WHERE id = ?",
            (account_id,),
        ).fetchone()


def login_required(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        account = current_account()
        if account is None:
            return jsonify({"error": "Please sign in first.", "code": "login_required"}), 401
        if not account["approved"]:
            session.clear()
            return jsonify({"error": "Your account is awaiting admin approval.", "code": "pending"}), 403
        return function(*args, **kwargs)

    return wrapped


def roles_required(*roles):
    def decorator(function):
        @wraps(function)
        @login_required
        def wrapped(*args, **kwargs):
            account = current_account()
            if account["role"] not in roles:
                return jsonify({"error": "You do not have permission to do this."}), 403
            return function(*args, **kwargs)

        return wrapped

    return decorator


def valid_coordinates(latitude, longitude):
    return (
        isinstance(latitude, (int, float))
        and not isinstance(latitude, bool)
        and -90 <= latitude <= 90
        and isinstance(longitude, (int, float))
        and not isinstance(longitude, bool)
        and -180 <= longitude <= 180
    )


def attendance_area(connection):
    values = {
        row["key"]: row["value"]
        for row in connection.execute("SELECT key, value FROM settings").fetchall()
    }
    try:
        latitude = float(values["area_latitude"])
        longitude = float(values["area_longitude"])
        radius = int(values["area_radius_meters"])
    except (KeyError, ValueError):
        return None
    return {
        "latitude": latitude,
        "longitude": longitude,
        "radiusMeters": radius,
        "label": values.get("area_label", "Attendance area"),
    }


def distance_in_meters(lat1, lon1, lat2, lon2):
    earth_radius = 6_371_000
    delta_lat = radians(lat2 - lat1)
    delta_lon = radians(lon2 - lon1)
    value = (
        sin(delta_lat / 2) ** 2
        + cos(radians(lat1)) * cos(radians(lat2)) * sin(delta_lon / 2) ** 2
    )
    return earth_radius * 2 * asin(sqrt(value))


def require_inside_area(latitude, longitude):
    if not valid_coordinates(latitude, longitude):
        return None, (jsonify({"error": "Valid location coordinates are required."}), 400)
    with get_db() as connection:
        area = attendance_area(connection)
    if area is None:
        return None, (
            jsonify({"error": "The administrator has not configured the attendance area."}),
            409,
        )
    distance = distance_in_meters(
        area["latitude"], area["longitude"], latitude, longitude
    )
    if distance > area["radiusMeters"]:
        return None, (
            jsonify(
                {
                    "error": (
                        f"You are outside the attendance area "
                        f"({round(distance)} m away; limit {area['radiusMeters']} m)."
                    ),
                    "distanceMeters": round(distance),
                    "radiusMeters": area["radiusMeters"],
                }
            ),
            403,
        )
    return area, None


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/auth/state")
@api_endpoint
def auth_state():
    with get_db() as connection:
        admin_exists = connection.execute(
            "SELECT 1 FROM accounts WHERE role = 'admin' LIMIT 1"
        ).fetchone() is not None
    account = current_account()
    return jsonify(
        {
            "setupRequired": not admin_exists,
            "account": (
                {
                    "id": account["id"],
                    "name": account["name"],
                    "username": account["username"],
                    "role": account["role"],
                    "approved": bool(account["approved"]),
                }
                if account
                else None
            ),
        }
    )


@app.post("/api/setup-admin")
@api_endpoint
def setup_admin():
    data = request.get_json(silent=True) or {}
    name = data.get("name", "")
    username = data.get("username", "")
    password = data.get("password", "")
    if not all(isinstance(value, str) for value in (name, username, password)):
        return jsonify({"error": "Enter a valid admin name, username, and password."}), 400
    name, username = name.strip(), username.strip()
    if len(name) < 2 or not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}", username):
        return jsonify({"error": "Name must be at least 2 characters and username 3–32 letters."}), 400
    if len(password) < 10:
        return jsonify({"error": "Admin password must be at least 10 characters."}), 400
    with get_db() as connection:
        if connection.execute(
            "SELECT 1 FROM accounts WHERE role = 'admin' LIMIT 1"
        ).fetchone():
            return jsonify({"error": "The administrator account is already configured."}), 409
        cursor = connection.execute(
            """
            INSERT INTO accounts (username, name, password_hash, role, approved, created_at)
            VALUES (?, ?, ?, 'admin', 1, ?)
            """,
            (
                username,
                name,
                generate_password_hash(password),
                datetime.now().isoformat(timespec="seconds"),
            ),
        )
    session.clear()
    session["account_id"] = cursor.lastrowid
    return jsonify({"message": "Admin account created.", "role": "admin"}), 201


@app.post("/api/register")
@api_endpoint
def register_account():
    data = request.get_json(silent=True) or {}
    name = data.get("name", "")
    username = data.get("username", "")
    password = data.get("password", "")
    role = data.get("role", "")
    if not all(isinstance(value, str) for value in (name, username, password, role)):
        return jsonify({"error": "Complete all registration fields."}), 400
    name, username = name.strip(), username.strip()
    if len(name) < 2 or not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}", username):
        return jsonify({"error": "Enter a name and a username (3–32 letters, numbers, . _ -)."}), 400
    if len(password) < 8:
        return jsonify({"error": "Password must be at least 8 characters."}), 400
    if role not in {"student", "employee"}:
        return jsonify({"error": "Choose Student or Employee."}), 400
    with get_db() as connection:
        admin_exists = connection.execute(
            "SELECT 1 FROM accounts WHERE role = 'admin' LIMIT 1"
        ).fetchone()
        if not admin_exists:
            return jsonify(
                {
                    "error": "Create the administrator account before registering students or employees.",
                    "code": "admin_setup_required",
                }
            ), 409
        if connection.execute(
            "SELECT 1 FROM accounts WHERE username = ? COLLATE NOCASE", (username,)
        ).fetchone():
            return jsonify({"error": "That username is already taken."}), 409
        connection.execute(
            """
            INSERT INTO accounts (username, name, password_hash, role, approved, created_at)
            VALUES (?, ?, ?, ?, 0, ?)
            """,
            (
                username,
                name,
                generate_password_hash(password),
                role,
                datetime.now().isoformat(timespec="seconds"),
            ),
        )
    return jsonify(
        {"message": "Registration submitted. An administrator must approve your account."}
    ), 201


@app.post("/api/login")
@api_endpoint
def login_account():
    data = request.get_json(silent=True) or {}
    username = data.get("username", "")
    password = data.get("password", "")
    role = data.get("role", "")
    if not all(isinstance(value, str) for value in (username, password, role)):
        return jsonify({"error": "Enter your username, password, and account type."}), 400
    with get_db() as connection:
        account = connection.execute(
            "SELECT * FROM accounts WHERE username = ? COLLATE NOCASE", (username.strip(),)
        ).fetchone()
    if not account or not check_password_hash(account["password_hash"], password):
        return jsonify({"error": "Username or password is incorrect."}), 401
    if account["role"] != role:
        return jsonify({"error": "Choose the account type assigned to your account."}), 403
    if not account["approved"]:
        return jsonify({"error": "Your account is awaiting admin approval.", "code": "pending"}), 403
    session.clear()
    session["account_id"] = account["id"]
    return jsonify(
        {
            "message": "Signed in.",
            "account": {
                "id": account["id"],
                "name": account["name"],
                "username": account["username"],
                "role": account["role"],
            },
        }
    )


@app.post("/api/logout")
@api_endpoint
def logout_account():
    session.clear()
    return jsonify({"message": "Signed out."})


@app.get("/api/area")
@api_endpoint
@login_required
def get_attendance_area():
    with get_db() as connection:
        return jsonify({"area": attendance_area(connection)})


@app.put("/api/area")
@api_endpoint
@roles_required("admin")
def update_attendance_area():
    data = request.get_json(silent=True) or {}
    latitude = data.get("latitude")
    longitude = data.get("longitude")
    radius = data.get("radiusMeters")
    label = data.get("label", "Attendance area")
    if not valid_coordinates(latitude, longitude):
        return jsonify({"error": "Choose a valid point on the map."}), 400
    if not isinstance(radius, int) or isinstance(radius, bool) or not 25 <= radius <= 5000:
        return jsonify({"error": "Radius must be between 25 and 5000 meters."}), 400
    if not isinstance(label, str) or not 2 <= len(label.strip()) <= 80:
        return jsonify({"error": "Area name must be between 2 and 80 characters."}), 400
    values = {
        "area_latitude": str(latitude),
        "area_longitude": str(longitude),
        "area_radius_meters": str(radius),
        "area_label": label.strip(),
    }
    with get_db() as connection:
        connection.executemany(
            "INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            values.items(),
        )
    return jsonify({"message": "Attendance area saved.", "area": {
        "latitude": latitude,
        "longitude": longitude,
        "radiusMeters": radius,
        "label": label.strip(),
    }})


@app.get("/api/admin/accounts")
@api_endpoint
@roles_required("admin")
def admin_accounts():
    with get_db() as connection:
        accounts = connection.execute(
            """
            SELECT accounts.id, accounts.name, accounts.username, accounts.role,
                   accounts.approved, accounts.person_id, accounts.created_at,
                   people.name AS person_name
            FROM accounts LEFT JOIN people ON people.id = accounts.person_id
            WHERE accounts.role != 'admin'
            ORDER BY accounts.approved, accounts.created_at DESC
            """
        ).fetchall()
        available_people = connection.execute(
            """
            SELECT id, name FROM people
            WHERE id NOT IN (SELECT person_id FROM accounts WHERE person_id IS NOT NULL)
            ORDER BY name COLLATE NOCASE
            """
        ).fetchall()
    return jsonify(
        {
            "accounts": [
                {
                    "id": row["id"],
                    "name": row["name"],
                    "username": row["username"],
                    "role": row["role"],
                    "approved": bool(row["approved"]),
                    "personId": row["person_id"],
                    "personName": row["person_name"],
                    "createdAt": row["created_at"],
                }
                for row in accounts
            ],
            "availablePeople": [
                {"id": row["id"], "name": row["name"]} for row in available_people
            ],
        }
    )


@app.post("/api/admin/accounts")
@api_endpoint
@roles_required("admin")
def create_account_by_admin():
    data = request.get_json(silent=True) or {}
    name = data.get("name", "")
    username = data.get("username", "")
    password = data.get("password", "")
    role = data.get("role", "")
    if not all(isinstance(value, str) for value in (name, username, password, role)):
        return jsonify({"error": "Complete all account fields."}), 400
    name, username = name.strip(), username.strip()
    if len(name) < 2 or not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}", username):
        return jsonify({"error": "Enter a name and a valid username (3–32 letters, numbers, . _ -)."}), 400
    if len(password) < 8 or role not in {"student", "employee"}:
        return jsonify({"error": "Use a password of at least 8 characters and choose a role."}), 400
    with get_db() as connection:
        person = connection.execute(
            "SELECT id FROM people WHERE name = ? COLLATE NOCASE", (name,)
        ).fetchone()
        if not person:
            return jsonify({"error": "Enroll this person's face before creating their account."}), 409
        if connection.execute(
            "SELECT 1 FROM accounts WHERE username = ? COLLATE NOCASE", (username,)
        ).fetchone():
            return jsonify({"error": "That username is already taken."}), 409
        if connection.execute(
            "SELECT 1 FROM accounts WHERE person_id = ?", (person["id"],)
        ).fetchone():
            return jsonify({"error": "This face profile is already linked to an account."}), 409
        cursor = connection.execute(
            """
            INSERT INTO accounts (username, name, password_hash, role, approved, person_id, created_at)
            VALUES (?, ?, ?, ?, 1, ?, ?)
            """,
            (
                username,
                name,
                generate_password_hash(password),
                role,
                person["id"],
                datetime.now().isoformat(timespec="seconds"),
            ),
        )
    return jsonify({"message": "Account created and linked to the face profile.", "id": cursor.lastrowid}), 201


@app.post("/api/admin/accounts/<int:account_id>/approve")
@api_endpoint
@roles_required("admin")
def approve_account(account_id):
    data = request.get_json(silent=True) or {}
    person_id = data.get("personId")
    if not isinstance(person_id, int) or isinstance(person_id, bool):
        return jsonify({"error": "Select an enrolled face profile to link."}), 400
    with get_db() as connection:
        account = connection.execute(
            "SELECT id, role FROM accounts WHERE id = ? AND role != 'admin'",
            (account_id,),
        ).fetchone()
        if not account:
            return jsonify({"error": "Account not found."}), 404
        if connection.execute(
            "SELECT 1 FROM people WHERE id = ?", (person_id,)
        ).fetchone() is None:
            return jsonify({"error": "Selected face profile was not found."}), 404
        if connection.execute(
            "SELECT 1 FROM accounts WHERE person_id = ? AND id != ?",
            (person_id, account_id),
        ).fetchone():
            return jsonify({"error": "That face profile is already linked to another account."}), 409
        connection.execute(
            "UPDATE accounts SET person_id = ?, approved = 1 WHERE id = ?",
            (person_id, account_id),
        )
    return jsonify({"message": "Account approved and linked to its face profile."})


@app.delete("/api/admin/accounts/<int:account_id>")
@api_endpoint
@roles_required("admin")
def delete_account(account_id):
    with get_db() as connection:
        cursor = connection.execute(
            "DELETE FROM accounts WHERE id = ? AND role != 'admin'", (account_id,)
        )
        if cursor.rowcount == 0:
            return jsonify({"error": "Account not found."}), 404
    return jsonify({"message": "Account removed."})


@app.get("/api/dashboard")
@api_endpoint
@login_required
def dashboard_data():
    today = date.today()
    week_start = today - timedelta(days=today.weekday())
    account = current_account()
    person_filter = ""
    person_params = ()
    if account["role"] != "admin":
        if account["person_id"] is None:
            return jsonify(
                {"error": "Your face profile is not linked yet. Ask an administrator to enroll you."}
            ), 409
        person_filter = " WHERE id = ?"
        person_params = (account["person_id"],)
    with get_db() as connection:
        people = connection.execute(
            "SELECT id, name, created_at FROM people"
            + person_filter
            + " ORDER BY name COLLATE NOCASE",
            person_params,
        ).fetchall()
        attendance_person_filter = ""
        attendance_params = ()
        if account["role"] != "admin":
            attendance_person_filter = " AND person_id = ?"
            attendance_params = (account["person_id"],)
        present_today = connection.execute(
            "SELECT COUNT(*) FROM attendance WHERE attended_on = ?"
            + attendance_person_filter,
            (today.isoformat(),) + attendance_params,
        ).fetchone()[0]
        recent = connection.execute(
            """
            SELECT people.id, people.name, attendance.checked_in_at, attendance.attended_on
            FROM attendance JOIN people ON people.id = attendance.person_id
            WHERE 1 = 1
            """
            + attendance_person_filter
            + """
            ORDER BY attendance.checked_in_at DESC LIMIT 8
            """,
            attendance_params,
        ).fetchall()
        daily = connection.execute(
            """
            SELECT attended_on, COUNT(*) AS count FROM attendance
            WHERE attended_on >= ? AND attended_on <= ?
            """
            + attendance_person_filter
            + """
            GROUP BY attended_on
            """,
            (week_start.isoformat(), today.isoformat()) + attendance_params,
        ).fetchall()
        attendance_days = connection.execute(
            "SELECT person_id, attended_on FROM attendance WHERE 1 = 1"
            + attendance_person_filter
            + " ORDER BY attended_on DESC",
            attendance_params,
        ).fetchall()
        area = attendance_area(connection)

    day_counts = {row["attended_on"]: row["count"] for row in daily}
    weekly = [
        {
            "day": (week_start + timedelta(days=offset)).strftime("%a"),
            "date": (week_start + timedelta(days=offset)).isoformat(),
            "count": day_counts.get((week_start + timedelta(days=offset)).isoformat(), 0),
        }
        for offset in range(7)
    ]
    days_by_person = {}
    for row in attendance_days:
        days_by_person.setdefault(row["person_id"], set()).add(
            date.fromisoformat(row["attended_on"])
        )
    streak_map = {}
    for person in people:
        days = days_by_person.get(person["id"], set())
        streak_day = today if today in days else today - timedelta(days=1)
        streak = 0
        while streak_day in days:
            streak += 1
            streak_day -= timedelta(days=1)
        streak_map[person["id"]] = streak
    return jsonify(
        {
            "date": today.isoformat(),
            "present": present_today,
            "total": len(people),
            "rate": round((present_today / len(people)) * 100) if people else 0,
            "weekly": weekly,
            "people": [
                {
                    "id": person["id"],
                    "name": person["name"],
                    "createdAt": person["created_at"],
                    "streak": streak_map.get(person["id"], 0),
                }
                for person in people
            ],
            "recent": [
                {
                    "id": row["id"],
                    "name": row["name"],
                    "checkedInAt": row["checked_in_at"],
                    "attendedOn": row["attended_on"],
                }
                for row in recent
            ],
        }
    )


@app.get("/api/health")
@api_endpoint
def api_health():
    recognition_libraries()
    return jsonify({"status": "ok", "faceRecognition": "opencv-lbph"})


@app.post("/api/enroll")
@api_endpoint
@roles_required("admin")
def enroll():
    data = request.get_json(silent=True) or {}
    name = data.get("name", "") if request.is_json else request.form.get("name", "")
    if not isinstance(name, str):
        return jsonify({"error": "Enter a valid name."}), 400
    name = " ".join(name.split())
    if not 2 <= len(name) <= 64 or not re.fullmatch(r"[\w .'-]+", name, re.UNICODE):
        return jsonify({"error": "Use a name between 2 and 64 letters."}), 400

    face_image = image_from_request()
    with get_db() as connection:
        duplicate = connection.execute(
            "SELECT id, embedding FROM people WHERE name = ? COLLATE NOCASE", (name,)
        ).fetchone()
        if duplicate:
            try:
                old_face = json.loads(duplicate["embedding"])
                is_current_format = (
                    isinstance(old_face, list)
                    and len(old_face) == FACE_SIZE[1]
                    and all(
                        isinstance(row, list) and len(row) == FACE_SIZE[0]
                        for row in old_face
                    )
                )
            except (TypeError, ValueError, json.JSONDecodeError):
                is_current_format = False
            if is_current_format:
                return jsonify({"error": "That name is already enrolled."}), 409
            connection.execute(
                "UPDATE people SET embedding = ? WHERE id = ?",
                (json.dumps(face_image.tolist()), duplicate["id"]),
            )
            return jsonify(
                {"message": f"{name}'s face has been updated.", "id": duplicate["id"]}
            ), 200
        cursor = connection.execute(
            "INSERT INTO people (name, embedding, created_at) VALUES (?, ?, ?)",
            (name, json.dumps(face_image.tolist()), datetime.now().isoformat(timespec="seconds")),
        )
    return jsonify({"message": f"{name} has been enrolled.", "id": cursor.lastrowid}), 201


@app.post("/api/recognize")
@api_endpoint
@roles_required("student", "employee")
def recognize():
    account = current_account()
    if account["person_id"] is None:
        return jsonify(
            {"error": "Your face profile is not linked yet. Ask an administrator to enroll you."}
        ), 409
    data = request.get_json(silent=True) or {}
    area, location_error = require_inside_area(
        data.get("latitude"), data.get("longitude")
    )
    if location_error:
        return location_error
    face_image = image_from_request()
    cv2, np = recognition_libraries()
    with get_db() as connection:
        people = connection.execute("SELECT id, name, embedding FROM people").fetchall()
        if not people:
            return jsonify({"error": "Enroll someone before starting recognition."}), 400
        training_faces = []
        labels = []
        for person in people:
            try:
                enrolled_face = np.asarray(json.loads(person["embedding"]), dtype=np.uint8)
                if enrolled_face.shape != FACE_SIZE:
                    continue
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            training_faces.append(enrolled_face)
            labels.append(person["id"])
        if not training_faces:
            return jsonify(
                {"error": "No compatible enrolled faces. Re-enroll people using this version."}
            ), 409
        model = cv2.face.LBPHFaceRecognizer_create()
        model.train(training_faces, np.asarray(labels, dtype=np.int32))
        predicted_id, distance = model.predict(face_image)
        confidence = max(
            0.0, min(100.0, (1.0 - float(distance) / FACE_MATCH_THRESHOLD) * 100)
        )
        if distance > FACE_MATCH_THRESHOLD:
            return jsonify({"matched": False, "message": "Face not recognized."})

        person = next((record for record in people if record["id"] == predicted_id), None)
        if person is None or person["id"] != account["person_id"]:
            return jsonify({"matched": False, "message": "Face not recognized."})
        today = date.today().isoformat()
        existing = connection.execute(
            "SELECT checked_in_at FROM attendance WHERE person_id = ? AND attended_on = ?",
            (person["id"], today),
        ).fetchone()
        if existing:
            return jsonify(
                {
                    "matched": True,
                    "alreadyMarked": True,
                    "name": person["name"],
                    "checkedInAt": existing["checked_in_at"],
                    "confidence": round(confidence),
                    "message": "Attendance was already marked today.",
                }
            )
        checked_in_at = datetime.now().isoformat(timespec="seconds")
        connection.execute(
            "INSERT INTO attendance (person_id, attended_on, checked_in_at) VALUES (?, ?, ?)",
            (person["id"], today, checked_in_at),
        )
    return jsonify(
        {
            "matched": True,
            "alreadyMarked": False,
            "name": person["name"],
            "checkedInAt": checked_in_at,
            "confidence": round(confidence),
            "message": f"Attendance marked for {person['name']}.",
        }
    )


@app.delete("/api/people/<int:person_id>")
@api_endpoint
@roles_required("admin")
def delete_person(person_id):
    with get_db() as connection:
        cursor = connection.execute("DELETE FROM people WHERE id = ?", (person_id,))
        if cursor.rowcount == 0:
            return jsonify({"error": "Person not found."}), 404
    return jsonify({"message": "Person and their attendance records were removed."})


@app.get("/api/attendance.csv")
@api_endpoint
@roles_required("admin")
def export_attendance():
    start = request.args.get("start", "")
    end = request.args.get("end", "")
    try:
        if start:
            date.fromisoformat(start)
        if end:
            date.fromisoformat(end)
    except ValueError:
        return jsonify({"error": "Dates must use YYYY-MM-DD format."}), 400

    query = """
        SELECT people.name, attendance.attended_on, attendance.checked_in_at
        FROM attendance JOIN people ON people.id = attendance.person_id
        WHERE (? = '' OR attendance.attended_on >= ?)
          AND (? = '' OR attendance.attended_on <= ?)
        ORDER BY attendance.attended_on DESC, attendance.checked_in_at DESC
    """
    with get_db() as connection:
        records = connection.execute(query, (start, start, end, end)).fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Name", "Date", "Check-in time"])
    writer.writerows(
        (row["name"], row["attended_on"], row["checked_in_at"]) for row in records
    )
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=attendance.csv"},
    )


@app.errorhandler(413)
def request_too_large(_error):
    return jsonify({"error": "The request is too large. Use an image under 4 MB."}), 413


init_db()

if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1")
